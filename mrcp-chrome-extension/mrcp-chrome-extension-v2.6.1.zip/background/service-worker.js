// background/service-worker.js - MRCP Engine Chrome Extension Background Service Worker

// 1. Configure native Side Panel behavior at top-level (Manifest V3 best practice)
function setupSidePanel() {
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel
      .setPanelBehavior({ openPanelOnActionClick: true })
      .catch((error) =>
        console.warn("[MRCP-Engine] Nota: setPanelBehavior:", error)
      );
  }
}

setupSidePanel();

// 2. Also ensure configuration on extension install or update
chrome.runtime.onInstalled.addListener(() => {
  console.log("[MRCP-Engine] Extensão inicializada com sucesso!");
  setupSidePanel();
});

// 3. Fallback action click listener in case setPanelBehavior is not supported by older Chrome versions
chrome.action.onClicked.addListener(async (tab) => {
  if (chrome.sidePanel && chrome.sidePanel.open) {
    try {
      const winId = tab.windowId || (await chrome.windows.getCurrent()).id;
      await chrome.sidePanel.open({ windowId: winId });
    } catch (err) {
      console.warn("[MRCP-Engine] Fallback de abertura do side panel:", err);
    }
  }
});

// 4. Central message bus between Content Scripts, Side Panel and Background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "openSidePanel") {
    (async () => {
      try {
        let winId = sender.tab?.windowId;
        if (!winId && chrome.windows) {
          const currentWin = await chrome.windows.getCurrent();
          winId = currentWin?.id;
        }

        if (chrome.sidePanel && chrome.sidePanel.open && winId) {
          await chrome.sidePanel.open({ windowId: winId });
        }

        if (message.repo) {
          // Store pending analysis so side panel picks it up on initial boot
          await chrome.storage.local.set({
            pendingRepoAnalysis: message.repo,
            pendingRepoProvider: message.provider || "github",
          });

          // Also notify if side panel is already active
          chrome.runtime
            .sendMessage({
              action: "analyzeRepo",
              repo: message.repo,
              provider: message.provider || "github",
            })
            .catch(() => {});
        }

        sendResponse({ status: "ok" });
      } catch (err) {
        sendResponse({ status: "error", error: err.message });
      }
    })();
    return true; // async response
  }

  if (message.action === "getCurrentTabInfo") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs.length > 0) {
        sendResponse({ tab: tabs[0] });
      } else {
        sendResponse({ tab: null });
      }
    });
    return true; // async response
  }
});
