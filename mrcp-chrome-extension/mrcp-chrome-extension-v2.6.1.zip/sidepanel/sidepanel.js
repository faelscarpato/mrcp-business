// sidepanel/sidepanel.js - MRCP Engine Cockpit Controller

import { MrcpEngine } from "../engine/mrcp-engine.js";
import { packWorkspaceContextForAi } from "../engine/context-packer.js";
import { generateDiagnosticMarkdownReport } from "../engine/report-generator.js";

// State
let engine = new MrcpEngine();
let lastResult = null;
let currentRepo = "";
let graphNodes = [];
let graphEdges = [];
let hoveredNode = null;
let isDragging = false;
let dragStartX = 0;
let dragStartY = 0;
let graphOffsetX = 0;
let graphOffsetY = 0;

// DOM Elements
const repoForm = document.getElementById("repo-form");
const repoInput = document.getElementById("repo-input");
const btnAnalyze = document.getElementById("btn-analyze");
const detectedBanner = document.getElementById("detected-tab-banner");
const detectedRepoName = document.getElementById("detected-repo-name");
const detectedProviderTag = document.getElementById("detected-provider-tag");
const detectedProviderIcon = document.getElementById("detected-provider-icon");
const btnAnalyzeDetected = document.getElementById("btn-analyze-detected");
const progressContainer = document.getElementById("progress-container");
const progressBarFill = document.getElementById("progress-bar-fill");
const progressStatusText = document.getElementById("progress-status-text");
const progressPercent = document.getElementById("progress-percent");
const errorAlert = document.getElementById("error-alert");
const errorMessage = document.getElementById("error-message");
const btnCloseError = document.getElementById("btn-close-error");
const emptyState = document.getElementById("empty-state");
const cockpitView = document.getElementById("cockpit-view");

// KPIs
const metaRepoName = document.getElementById("meta-repo-name");
const metaRevision = document.getElementById("meta-revision");
const metaTime = document.getElementById("meta-time");
const badgeLetterGrade = document.getElementById("badge-letter-grade");
const kpiHealthScore = document.getElementById("kpi-health-score");
const kpiGradeDesc = document.getElementById("kpi-grade-desc");
const kpiMaintainability = document.getElementById("kpi-maintainability");
const kpiAvgComplexity = document.getElementById("kpi-avg-complexity");
const kpiTokenSavings = document.getElementById("kpi-token-savings");
const kpiTokenComparison = document.getElementById("kpi-token-comparison");
const kpiDqi = document.getElementById("kpi-dqi");
const kpiDocCount = document.getElementById("kpi-doc-count");

// Actions & Modals
const btnCopyAi = document.getElementById("btn-copy-ai");
const btnExportReport = document.getElementById("btn-export-report");
const btnReanalyze = document.getElementById("btn-reanalyze");
const btnSettings = document.getElementById("btn-settings");
const settingsModal = document.getElementById("settings-modal");
const btnCloseModal = document.getElementById("btn-close-modal");
const ghTokenInput = document.getElementById("gh-token-input");
const glTokenInput = document.getElementById("gl-token-input");
const btnSaveSettings = document.getElementById("btn-save-settings");
const toast = document.getElementById("toast");
const depCanvas = document.getElementById("dep-graph-canvas");
const graphTooltip = document.getElementById("graph-tooltip");

// Initialize
document.addEventListener("DOMContentLoaded", async () => {
  await loadSavedSettings();
  setupEventListeners();
  setupTabMonitoring();
  await checkCurrentTab();
});

// Load GitHub & GitLab tokens and check pending analysis from storage
async function loadSavedSettings() {
  try {
    if (chrome && chrome.storage && chrome.storage.local) {
      const data = await chrome.storage.local.get([
        "githubToken",
        "gitlabToken",
        "pendingRepoAnalysis",
      ]);
      if (data && data.githubToken) {
        engine.setToken(data.githubToken);
        if (ghTokenInput) ghTokenInput.value = data.githubToken;
      }
      if (data && data.gitlabToken) {
        engine.setGitlabToken(data.gitlabToken);
        if (glTokenInput) glTokenInput.value = data.gitlabToken;
      }
      // If user clicked the 1-click button on GitHub/GitLab before panel opened
      if (data && data.pendingRepoAnalysis) {
        const repoToAnalyze = data.pendingRepoAnalysis;
        await chrome.storage.local.remove("pendingRepoAnalysis");
        repoInput.value = repoToAnalyze;
        startAnalysis(repoToAnalyze);
      }
    }
  } catch (err) {
    console.warn("[MRCP] Erro ao carregar configurações:", err);
  }
}

// Check active tab to detect GitHub or GitLab repository
async function checkCurrentTab() {
  try {
    if (!chrome || !chrome.tabs || !chrome.tabs.query) return;

    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs || tabs.length === 0) return;

    const activeTab = tabs[0];
    if (!activeTab.url) return;

    const parsed = engine.fetcher.parseRepoUrl(activeTab.url);
    if (parsed) {
      const slug = parsed.fullName;
      detectedRepoName.textContent = slug;
      if (detectedProviderTag) {
        detectedProviderTag.textContent =
          parsed.provider === "gitlab" ? "GitLab" : "GitHub";
      }
      if (detectedProviderIcon) {
        detectedProviderIcon.textContent =
          parsed.provider === "gitlab" ? "🦊" : "🐙";
      }
      detectedBanner.classList.remove("hidden");
      if (!repoInput.value || !currentRepo) {
        repoInput.value = slug;
      }
    } else {
      detectedBanner.classList.add("hidden");
    }
  } catch (err) {
    console.warn("[MRCP] Erro ao consultar aba ativa:", err);
  }
}

// Setup real-time tab switching and extension message bus
function setupTabMonitoring() {
  // Listen to tab switching
  if (chrome && chrome.tabs && chrome.tabs.onActivated) {
    chrome.tabs.onActivated.addListener(async () => {
      await checkCurrentTab();
    });
  }

  // Listen to tab URL navigations
  if (chrome && chrome.tabs && chrome.tabs.onUpdated) {
    chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
      if (changeInfo.status === "complete" || changeInfo.url) {
        await checkCurrentTab();
      }
    });
  }

  // Listen to runtime messages (e.g. from content script 1-click button)
  if (chrome && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.action === "analyzeRepo" && msg.repo) {
        repoInput.value = msg.repo;
        detectedRepoName.textContent = msg.repo;
        detectedBanner.classList.remove("hidden");
        startAnalysis(msg.repo);
      } else if (msg.action === "selectRepo" && msg.repo) {
        repoInput.value = msg.repo;
        detectedRepoName.textContent = msg.repo;
        detectedBanner.classList.remove("hidden");
      }
    });
  }
}

// Setup Event Listeners
function setupEventListeners() {
  repoForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const val = repoInput.value.trim();
    if (val) startAnalysis(val);
  });

  btnAnalyzeDetected.addEventListener("click", () => {
    const slug = detectedRepoName.textContent.trim();
    if (slug) {
      repoInput.value = slug;
      startAnalysis(slug);
    }
  });

  btnCloseError.addEventListener("click", () => {
    errorAlert.classList.add("hidden");
  });

  // Sample chips
  document.querySelectorAll(".sample-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const repo = chip.dataset.repo;
      repoInput.value = repo;
      startAnalysis(repo);
    });
  });

  // Tab navigation
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const tabId = btn.dataset.tab;
      switchTab(tabId);
    });
  });

  // Copy AI Context
  btnCopyAi.addEventListener("click", async () => {
    if (!lastResult) return;
    try {
      const contextText = packWorkspaceContextForAi(lastResult);
      await navigator.clipboard.writeText(contextText);
      showToast("📋 Contexto Otimizado para IA copiado!");
    } catch (err) {
      showToast("❌ Erro ao copiar contexto!");
    }
  });

  // Export Report MD
  btnExportReport.addEventListener("click", () => {
    if (!lastResult) return;
    try {
      const md = generateDiagnosticMarkdownReport(lastResult);
      const blob = new Blob([md], { type: "text/markdown;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `MRCP_DIAGNOSTIC_${lastResult.workspaceRoot.replace(/\//g, "_")}.md`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast("📄 Relatório Markdown baixado com sucesso!");
    } catch (err) {
      showToast("❌ Erro ao exportar relatório!");
    }
  });

  // Reanalyze
  btnReanalyze.addEventListener("click", () => {
    if (currentRepo) startAnalysis(currentRepo);
  });

  // Settings modal
  btnSettings.addEventListener("click", () => {
    settingsModal.classList.remove("hidden");
  });
  btnCloseModal.addEventListener("click", () => {
    settingsModal.classList.add("hidden");
  });
  settingsModal.querySelector(".modal-overlay").addEventListener("click", () => {
    settingsModal.classList.add("hidden");
  });
  btnSaveSettings.addEventListener("click", async () => {
    const ghToken = ghTokenInput ? ghTokenInput.value.trim() : "";
    const glToken = glTokenInput ? glTokenInput.value.trim() : "";
    engine.setToken(ghToken);
    engine.setGitlabToken(glToken);
    if (chrome && chrome.storage && chrome.storage.local) {
      await chrome.storage.local.set({
        githubToken: ghToken,
        gitlabToken: glToken,
      });
    }
    settingsModal.classList.add("hidden");
    showToast("⚙️ Configurações salvas!");
  });

  // Canvas interaction
  setupGraphCanvas();
}

function switchTab(tabId) {
  document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
  document.querySelectorAll(".tab-pane").forEach((p) => p.classList.remove("active"));

  const targetBtn = document.querySelector(`.tab-btn[data-tab="${tabId}"]`);
  const targetPane = document.getElementById(`tab-${tabId}`);
  if (targetBtn) targetBtn.classList.add("active");
  if (targetPane) targetPane.classList.add("active");

  if (tabId === "graph") {
    requestAnimationFrame(renderGraph);
  }
}

// Start Repository Analysis
async function startAnalysis(repoSlug) {
  currentRepo = repoSlug;
  hideError();
  showProgress(true);
  btnAnalyze.disabled = true;

  try {
    const result = await engine.analyzeRepository(repoSlug, (pct, msg) => {
      updateProgress(pct, msg);
    });

    lastResult = result;
    renderCockpit(result);
    emptyState.classList.add("hidden");
    cockpitView.classList.remove("hidden");
    showToast("⚡ Análise MRCP concluída com sucesso!");
  } catch (err) {
    showError(err.message || "Erro desconhecido ao analisar o repositório.");
  } finally {
    showProgress(false);
    btnAnalyze.disabled = false;
  }
}

// Update UI with analysis results
function renderCockpit(res) {
  const { summary, provenance, godModules, securityIssues, envIssues, testGaps, deadCodeItems, documents, apiRoutes, files } = res;

  // Header meta
  metaRepoName.textContent = res.workspaceRoot;
  metaRevision.textContent = provenance.repositoryRevision;
  metaTime.textContent = new Date(res.timestamp).toLocaleTimeString();

  // Grade badge
  badgeLetterGrade.textContent = summary.letterGrade;
  badgeLetterGrade.className = `grade-badge grade-${summary.letterGrade}`;

  // KPIs
  kpiHealthScore.textContent = summary.healthScore;
  kpiMaintainability.textContent = summary.maintainabilityIndex;
  kpiAvgComplexity.textContent = summary.avgComplexity;
  kpiTokenSavings.textContent = `~${summary.tokenSavingsPercent}%`;
  kpiTokenComparison.textContent = `${(summary.estimatedTokensWithMrcp / 1000).toFixed(1)}k vs ${(summary.estimatedTokensWithoutMrcp / 1000).toFixed(1)}k brutos`;
  kpiDqi.textContent = summary.documentQualityScore;
  kpiDocCount.textContent = `${documents.length} docs indexados`;

  let gradeDesc = "Saúde excelente";
  if (summary.letterGrade === "B") gradeDesc = "Bom estado / pequenos ajustes";
  else if (summary.letterGrade === "C") gradeDesc = "Atenção: dívida técnica moderada";
  else if (summary.letterGrade === "D" || summary.letterGrade === "F") gradeDesc = "Crítico: alta complexidade e riscos";
  kpiGradeDesc.textContent = gradeDesc;

  // Counts
  document.getElementById("count-god").textContent = godModules.length;
  document.getElementById("count-sec").textContent = securityIssues.length + envIssues.length;
  document.getElementById("count-qual").textContent = testGaps.length + deadCodeItems.length;
  document.getElementById("count-docs").textContent = documents.length;
  document.getElementById("count-api").textContent = apiRoutes.length;

  // ROI Banner
  document.getElementById("roi-raw-tokens").textContent = `${summary.estimatedTokensWithoutMrcp.toLocaleString()} tokens`;
  document.getElementById("roi-mrcp-tokens").textContent = `${summary.estimatedTokensWithMrcp.toLocaleString()} tokens`;
  const saved = Math.max(0, summary.estimatedTokensWithoutMrcp - summary.estimatedTokensWithMrcp);
  document.getElementById("roi-savings").textContent = `~${saved.toLocaleString()} tokens (${summary.tokenSavingsPercent}%)`;
  document.getElementById("roi-cost").textContent = `~$${((saved / 1000) * 0.003).toFixed(2)} USD`;

  // Hotspots table
  renderHotspotsTable(files);

  // God modules table
  renderGodModulesTable(godModules);

  // Security table
  renderSecurityTable(securityIssues, envIssues);

  // Quality table
  renderQualityTable(testGaps, deadCodeItems);

  // Documents table
  renderDocumentsTable(documents);

  // API table
  renderApiTable(apiRoutes);

  // Prepare dependency graph
  buildGraphData(res);
}

function renderHotspotsTable(files) {
  const tbody = document.getElementById("tbody-hotspots");
  tbody.innerHTML = "";

  const sorted = [...files].sort((a, b) => b.linesCount - a.linesCount).slice(0, 30);
  for (const f of sorted) {
    const tr = document.createElement("tr");
    const statusBadge = f.isGodModule
      ? '<span class="badge badge-high">God Module</span>'
      : '<span class="badge badge-low">Saudável</span>';

    tr.innerHTML = `
      <td class="code-cell" title="${f.relativePath}">${f.relativePath}</td>
      <td>${f.linesCount}</td>
      <td><strong>${f.complexity}</strong></td>
      <td>${f.symbols.length}</td>
      <td>${statusBadge}</td>
    `;
    tbody.appendChild(tr);
  }
}

function renderGodModulesTable(godModules) {
  const tbody = document.getElementById("tbody-godmodules");
  tbody.innerHTML = "";

  if (godModules.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; padding: 16px; color: var(--text-muted);">✅ Nenhum God Module detectado! Código altamente modular.</td></tr>`;
    return;
  }

  for (const g of godModules) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="code-cell" title="${g.file}">${g.file}</td>
      <td><strong>${g.linesCount}</strong></td>
      <td><span class="badge badge-medium">${g.complexity}</span></td>
      <td>${g.reason}</td>
    `;
    tbody.appendChild(tr);
  }
}

function renderSecurityTable(secIssues, envIssues) {
  const tbody = document.getElementById("tbody-security");
  tbody.innerHTML = "";

  if (secIssues.length === 0 && envIssues.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; padding: 16px; color: var(--text-muted);">✅ Nenhuma vulnerabilidade ou vazamento detectado pelas regras ativas.</td></tr>`;
    return;
  }

  for (const s of secIssues) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><span class="badge badge-${s.severity}">${s.severity}</span></td>
      <td><strong>${s.rule}:</strong> ${s.message}</td>
      <td class="code-cell" title="${s.file}:${s.line}">${s.file}:${s.line}</td>
      <td>${s.remediation || "Isolar credencial."}</td>
    `;
    tbody.appendChild(tr);
  }

  for (const e of envIssues) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><span class="badge badge-medium">ENV_MISS</span></td>
      <td>Variável <code>${e.variableName}</code> usada sem declaração em .env</td>
      <td class="code-cell" title="${e.file}:${e.line}">${e.file}:${e.line}</td>
      <td>Declarar no .env e .env.example</td>
    `;
    tbody.appendChild(tr);
  }
}

function renderQualityTable(testGaps, deadCode) {
  const tbody = document.getElementById("tbody-quality");
  tbody.innerHTML = "";

  if (testGaps.length === 0 && deadCode.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; padding: 16px; color: var(--text-muted);">✅ Zero código morto e excelente cobertura em funções complexas!</td></tr>`;
    return;
  }

  for (const d of deadCode) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><span class="badge badge-medium">Código Morto</span></td>
      <td><strong>${d.symbolName}</strong> (${d.kind})</td>
      <td class="code-cell" title="${d.file}:${d.line}">${d.file}:${d.line}</td>
      <td>${d.reason || "Sem referências cruzadas."}</td>
    `;
    tbody.appendChild(tr);
  }

  for (const g of testGaps) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><span class="badge badge-low">Gap Teste</span></td>
      <td><strong>${g.functionName}()</strong></td>
      <td class="code-cell" title="${g.file}:${g.line}">${g.file}:${g.line}</td>
      <td>Complexidade (${g.complexity}) sem teste unitário correspondente detectado.</td>
    `;
    tbody.appendChild(tr);
  }
}

function renderDocumentsTable(docs) {
  const tbody = document.getElementById("tbody-documents");
  tbody.innerHTML = "";

  if (docs.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; padding: 16px; color: var(--text-muted);">Nenhum documento Markdown indexado.</td></tr>`;
    return;
  }

  for (const d of docs) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="code-cell" title="${d.file}">${d.file}</td>
      <td><strong>${d.format}</strong></td>
      <td>${Math.round(d.size / 1024)} KB</td>
      <td>${d.wordCount}</td>
      <td><span class="badge badge-low">${d.qualityScore}/100</span></td>
    `;
    tbody.appendChild(tr);
  }
}

function renderApiTable(routes) {
  const tbody = document.getElementById("tbody-api");
  tbody.innerHTML = "";

  if (routes.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; padding: 16px; color: var(--text-muted);">Nenhuma rota REST/RPC detectada explicitamente.</td></tr>`;
    return;
  }

  for (const r of routes) {
    const tr = document.createElement("tr");
    const methods = r.acceptedMethods ? r.acceptedMethods.join(", ") : r.method;
    tr.innerHTML = `
      <td><span class="badge badge-low">${methods}</span></td>
      <td class="code-cell" title="${r.path}"><code>${r.path}</code></td>
      <td class="code-cell" title="${r.file}">${r.file}</td>
      <td>${r.description || r.source}</td>
    `;
    tbody.appendChild(tr);
  }
}

// Visual Dependency Graph
function buildGraphData(res) {
  const { files, godModules, dependencyCycles } = res;
  graphNodes = [];
  graphEdges = [];

  const godSet = new Set(godModules.map((g) => g.file));
  const cycleSet = new Set();
  dependencyCycles.forEach((c) => c.files.forEach((f) => cycleSet.add(f)));

  const fileMap = new Map();
  const subset = files.slice(0, 30); // Top 30 nodes for clean rendering
  const width = depCanvas.width || 480;
  const height = depCanvas.height || 340;
  const centerX = width / 2;
  const centerY = height / 2;
  const radius = Math.min(width, height) * 0.38;

  subset.forEach((f, i) => {
    const angle = (i / subset.length) * 2 * Math.PI;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    const node = {
      id: f.relativePath,
      name: f.relativePath.split("/").pop(),
      path: f.relativePath,
      x,
      y,
      radius: Math.min(14, Math.max(6, Math.sqrt(f.linesCount) / 2)),
      isGod: godSet.has(f.relativePath),
      isCycle: cycleSet.has(f.relativePath),
      complexity: f.complexity,
      lines: f.linesCount,
    };
    graphNodes.push(node);
    fileMap.set(f.relativePath, node);
  });

  subset.forEach((f) => {
    const sourceNode = fileMap.get(f.relativePath);
    if (!sourceNode) return;
    f.imports.forEach((imp) => {
      const targetNode = fileMap.get(imp);
      if (targetNode) {
        graphEdges.push({ source: sourceNode, target: targetNode });
      }
    });
  });
}

function setupGraphCanvas() {
  if (!depCanvas) return;

  depCanvas.addEventListener("mousemove", (e) => {
    const rect = depCanvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left - graphOffsetX;
    const mouseY = e.clientY - rect.top - graphOffsetY;

    hoveredNode = null;
    for (const node of graphNodes) {
      const dist = Math.hypot(node.x - mouseX, node.y - mouseY);
      if (dist <= node.radius + 4) {
        hoveredNode = node;
        break;
      }
    }

    if (hoveredNode) {
      graphTooltip.classList.remove("hidden");
      graphTooltip.style.left = `${e.clientX - rect.left + 12}px`;
      graphTooltip.style.top = `${e.clientY - rect.top + 12}px`;
      graphTooltip.innerHTML = `
        <strong>${hoveredNode.name}</strong><br>
        <span style="opacity: 0.8;">${hoveredNode.path}</span><br>
        Linhas: ${hoveredNode.lines} | Complexidade: ${hoveredNode.complexity}
        ${hoveredNode.isGod ? '<br><span style="color: #ef4444;">⚠️ God Module</span>' : ""}
        ${hoveredNode.isCycle ? '<br><span style="color: #f59e0b;">🔄 Ciclo de Dependência</span>' : ""}
      `;
    } else {
      graphTooltip.classList.add("hidden");
    }

    renderGraph();
  });

  depCanvas.addEventListener("mouseleave", () => {
    hoveredNode = null;
    graphTooltip.classList.add("hidden");
    renderGraph();
  });

  // Pan / Dragging
  depCanvas.addEventListener("mousedown", (e) => {
    isDragging = true;
    dragStartX = e.clientX - graphOffsetX;
    dragStartY = e.clientY - graphOffsetY;
  });

  window.addEventListener("mouseup", () => {
    isDragging = false;
  });

  window.addEventListener("mousemove", (e) => {
    if (!isDragging) return;
    graphOffsetX = e.clientX - dragStartX;
    graphOffsetY = e.clientY - dragStartY;
    renderGraph();
  });
}

function renderGraph() {
  if (!depCanvas) return;
  const ctx = depCanvas.getContext("2d");
  const width = depCanvas.width;
  const height = depCanvas.height;

  ctx.clearRect(0, 0, width, height);
  ctx.save();
  ctx.translate(graphOffsetX, graphOffsetY);

  // Draw edges
  ctx.lineWidth = 1;
  for (const edge of graphEdges) {
    const isHighlight =
      hoveredNode &&
      (hoveredNode === edge.source || hoveredNode === edge.target);

    ctx.beginPath();
    ctx.moveTo(edge.source.x, edge.source.y);
    ctx.lineTo(edge.target.x, edge.target.y);
    ctx.strokeStyle = isHighlight
      ? "#38bdf8"
      : "rgba(255, 255, 255, 0.12)";
    ctx.lineWidth = isHighlight ? 2 : 1;
    ctx.stroke();
  }

  // Draw nodes
  for (const node of graphNodes) {
    ctx.beginPath();
    ctx.arc(node.x, node.y, node.radius, 0, 2 * Math.PI);

    if (node.isGod) {
      ctx.fillStyle = "#ef4444";
    } else if (node.isCycle) {
      ctx.fillStyle = "#f59e0b";
    } else {
      ctx.fillStyle = "#6366f1";
    }

    ctx.fill();

    if (hoveredNode === node) {
      ctx.lineWidth = 3;
      ctx.strokeStyle = "#ffffff";
      ctx.stroke();
    }

    // Node label
    ctx.font = "9px " + getComputedStyle(document.body).fontFamily;
    ctx.fillStyle = "#94a3b8";
    ctx.textAlign = "center";
    ctx.fillText(node.name, node.x, node.y + node.radius + 10);
  }

  ctx.restore();
}

// Helpers
function showProgress(visible) {
  if (visible) {
    progressContainer.classList.remove("hidden");
    progressBarFill.style.width = "0%";
    progressPercent.textContent = "0%";
  } else {
    progressContainer.classList.add("hidden");
  }
}

function updateProgress(percent, text) {
  progressBarFill.style.width = `${percent}%`;
  progressPercent.textContent = `${percent}%`;
  if (text) progressStatusText.textContent = text;
}

function showError(msg) {
  errorMessage.textContent = msg;
  errorAlert.classList.remove("hidden");
}

function hideError() {
  errorAlert.classList.add("hidden");
}

function showToast(msg) {
  toast.textContent = msg;
  toast.classList.remove("hidden");
  setTimeout(() => {
    toast.classList.add("hidden");
  }, 2800);
}
