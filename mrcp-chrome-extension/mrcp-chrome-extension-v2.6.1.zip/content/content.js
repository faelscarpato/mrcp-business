// content/content.js - Injected into GitHub and GitLab pages

(function () {
  function getRepoDetails() {
    const url = window.location.href;

    // 1. GitLab detection
    const glMatch = url.match(
      /^https?:\/\/(?:www\.)?gitlab\.com\/([a-zA-Z0-9_\-./]+?)(?:\/-\/(?:tree|blob)\/([^/?#]+)|\/?$)/i
    );
    if (glMatch) {
      let fullPath = glMatch[1].replace(/^\/+|\/+$/g, "");
      const topLevel = fullPath.split("/")[0].toLowerCase();
      const glIgnored = [
        "explore",
        "dashboard",
        "users",
        "help",
        "search",
        "admin",
        "profile",
        "groups",
      ];
      if (!glIgnored.includes(topLevel) && fullPath.includes("/")) {
        const parts = fullPath.split("/");
        const repo = parts.pop().replace(/\.git$/, "");
        const owner = parts.join("/");
        return {
          provider: "gitlab",
          owner,
          repo,
          fullName: fullPath,
        };
      }
    }

    // 2. GitHub detection
    const ghMatch = url.match(
      /^https?:\/\/(?:www\.)?github\.com\/([a-zA-Z0-9_.-]+)\/([a-zA-Z0-9_.-]+)/i
    );
    if (ghMatch) {
      const owner = ghMatch[1];
      const repo = ghMatch[2].replace(/\.git$/, "");
      const ghIgnored = [
        "settings",
        "marketplace",
        "explore",
        "topics",
        "trending",
        "collections",
        "notifications",
      ];
      if (!ghIgnored.includes(owner.toLowerCase())) {
        return {
          provider: "github",
          owner,
          repo,
          fullName: `${owner}/${repo}`,
        };
      }
    }

    return null;
  }

  function injectMrcpButton() {
    const existing = document.getElementById("mrcp-quick-action-btn");
    const repoInfo = getRepoDetails();

    if (!repoInfo) {
      if (existing) existing.remove();
      return;
    }

    if (existing) {
      // Check if repo changed
      if (existing.dataset.repo === repoInfo.fullName) return;
      existing.remove();
    }

    // Find host action container
    const pageActions =
      // GitHub containers
      document.querySelector("#repository-details-container") ||
      document.querySelector(".pagehead-actions") ||
      document.querySelector("ul.pagehead-actions") ||
      document.querySelector(".d-flex.gap-2.flex-items-center") ||
      // GitLab containers
      document.querySelector(".tree-controls") ||
      document.querySelector(".project-repo-buttons") ||
      document.querySelector(".gl-display-flex.gl-gap-3") ||
      document.querySelector("[data-testid='tree-controls']") ||
      document.querySelector(".top-area .nav-controls");

    const container = document.createElement("div");
    container.id = "mrcp-quick-action-btn";
    container.dataset.repo = repoInfo.fullName;

    const isFloating = !pageActions;
    if (isFloating) {
      container.style.cssText = `
        position: fixed;
        bottom: 24px;
        right: 24px;
        z-index: 99999;
      `;
    } else {
      container.style.cssText = `
        display: inline-flex;
        align-items: center;
        margin-left: 8px;
        vertical-align: middle;
      `;
    }

    const providerIcon = repoInfo.provider === "gitlab" ? "🦊" : "🐙";
    const btn = document.createElement("button");
    btn.type = "button";
    btn.innerHTML = `<span style="margin-right: 5px;">⚡</span><span>MRCP Cockpit</span> <span style="font-size: 10px; opacity: 0.85; margin-left: 4px;">${providerIcon}</span>`;
    btn.title = `Abrir Análise MRCP Engine para ${repoInfo.fullName} no Painel Lateral`;
    btn.style.cssText = `
      display: inline-flex;
      align-items: center;
      background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
      color: #ffffff;
      border: 1px solid rgba(255,255,255,0.25);
      border-radius: 6px;
      padding: 5px 12px;
      font-size: 12px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 3px 8px rgba(79, 70, 229, 0.4);
      transition: transform 0.15s ease, box-shadow 0.15s ease;
      line-height: 1.4;
    `;

    btn.addEventListener("mouseenter", () => {
      btn.style.transform = "translateY(-1px)";
      btn.style.boxShadow = "0 5px 12px rgba(79, 70, 229, 0.55)";
    });
    btn.addEventListener("mouseleave", () => {
      btn.style.transform = "none";
      btn.style.boxShadow = "0 3px 8px rgba(79, 70, 229, 0.4)";
    });

    btn.addEventListener("click", () => {
      btn.innerHTML = `<span style="margin-right: 5px;">⏳</span><span>Abrindo...</span>`;
      chrome.runtime.sendMessage(
        {
          action: "openSidePanel",
          repo: repoInfo.fullName,
          provider: repoInfo.provider,
        },
        () => {
          setTimeout(() => {
            btn.innerHTML = `<span style="margin-right: 5px;">⚡</span><span>MRCP Cockpit</span> <span style="font-size: 10px; opacity: 0.85; margin-left: 4px;">${providerIcon}</span>`;
          }, 1500);
        }
      );
    });

    container.appendChild(btn);

    if (pageActions) {
      pageActions.appendChild(container);
    } else {
      document.body.appendChild(container);
    }
  }

  // Initial load
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", injectMrcpButton);
  } else {
    injectMrcpButton();
  }

  // SPA navigation events for GitHub and GitLab
  document.addEventListener("turbo:render", injectMrcpButton);
  document.addEventListener("turbo:load", injectMrcpButton);
  document.addEventListener("pjax:end", injectMrcpButton);
  window.addEventListener("popstate", injectMrcpButton);

  // Periodic safety check for client-side routing
  let lastUrl = window.location.href;
  setInterval(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      injectMrcpButton();
    }
  }, 1000);
})();
