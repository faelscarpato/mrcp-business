# 🚀 MRCP Engine — Google Chrome Extension (Manifest V3)

> **Code Intelligence, Architecture Cockpit & Deterministic AI Context Packer**
> Painel lateral direito nativo no Google Chrome para auditoria arquitetural, extração de contratos AST e redução de até 95% no consumo de tokens para agentes de IA.

---

## 📸 Demonstração Visual

### 1. Painel Lateral Nativo (Chrome Side Panel)
O **MRCP Engine** roda de forma totalmente integrada à barra lateral direita do Google Chrome, mantendo sua área de trabalho limpa e pronta para auditorias em tempo real:

<p align="center">
  <img src="captura_sidebar_aberto.png" alt="MRCP Engine no Chrome Side Panel" width="380" />
</p>

- **Detecção Automática da Aba**: Reconhece repositórios do GitHub (`faelscarpato/mrcp-engine`) e GitLab instantaneamente.
- **Cockpit de KPIs**: Health Score (0-100), Manutenibilidade SEI (0-100), Grau de Saúde (A–F) e Economia Real de Tokens (~94%).
- **Abas Diagnósticas Integradas**: Visão Geral, God Modules, Segurança & Segredos, Gaps de Teste, Documentação (DQI), Rotas de API e Grafo de Dependências interativo.

---

### 2. Ação Rápida no Cabeçalho do GitHub & GitLab
Ao acessar a página de qualquer repositório, o botão de ação rápida **⚡ MRCP Cockpit** é inserido nativamente na barra de ferramentas:

<p align="center">
  <img src="captura_botao_no_header_do_github.png" alt="Botão MRCP Cockpit no cabeçalho do GitHub" width="850" />
</p>

Basta um clique no botão **⚡ MRCP Cockpit** para acionar o diagnóstico e carregar todas as métricas arquiteturais diretamente no painel lateral!

---

## 🌟 Principais Recursos

1. **Abertura Nativa no Painel Lateral Direito (Chrome Side Panel)**:
   - Utiliza a API nativa `chrome.sidePanel` em Manifest V3 com `default_path: "sidepanel/sidepanel.html"`.
   - Ativado com `chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })` para abertura instantânea na barra lateral direita ao clicar no ícone.
2. **Auto-Detecção e Monitoramento em Tempo Real de Abas (GitHub & GitLab)**:
   - Monitora ativamente a troca de abas (`chrome.tabs.onActivated`, `chrome.tabs.onUpdated`) e detecta repositórios do **GitHub** e **GitLab** em tempo real.
   - Banner inteligente no topo do Side Panel com identificação visual do provedor (🐙 GitHub / 🦊 GitLab) e botão `⚡ Analisar Aba` em 1 clique.
   - Injeção de botão de ação rápida `⚡ MRCP Cockpit` nas páginas de repositórios do GitHub e GitLab com fallback resiliente.
   - Suporte a busca manual por `owner/repo`, `gitlab:group/repo` ou qualquer URL completa.
3. **Cockpit Executivo & KPIs em Tempo Real**:
   - **Health Score (0-100)** e Nota Geral (**Grade A, B, C, D, F**).
   - **Índice de Manutenibilidade (SEI Standard 0-100)** e Complexidade Ciclomática Média por função.
   - **Comprovante de Eficiência & ROI de Tokens LLM (~90% a 98% de redução)**: cálculo de tokens brutos vs tokens otimizados MRCP e estimativa de economia em USD por requisição.
   - **Índice de Qualidade Documental (DQI)**.
4. **Abas Diagnósticas Detalhadas**:
   - 📊 **Visão Geral & Hotspots**: Lista dos maiores arquivos, complexidade, volume de linhas e status de saúde.
   - 🏛️ **God Modules**: Detecção de arquivos monolíticos por volume de linhas (>750 LOC), excesso de símbolos e densidade de ramificação.
   - 🛡️ **Segurança & Segredos**: Varredura de chaves AWS, chaves privadas SSH/RSA, tokens GitHub/GitLab, JWTs e variáveis de ambiente `.env` não declaradas.
   - 🧪 **Gaps de Testes & Código Morto**: Identificação de funções públicas de alta complexidade sem cobertura detectada e exports zumbis.
   - 📄 **Documentos & DQI**: Análise de documentação técnica (.md, .txt, .json, .yaml) com pontuação de qualidade.
   - 🌐 **Contratos de Rotas de API**: Mapeamento de endpoints REST/RPC (Express, Next.js App/Pages Router, FastAPI, Flask, MCP protocol).
   - 🕸️ **Grafo Visual Interativo de Dependências**: Renderizado em HTML5 Canvas interativo com destaque em cores para módulos saudáveis, ciclos de dependência e God Modules, com pan/arraste e tooltips dinâmicos.
5. **Ações para IA & Engenharia**:
   - 📋 **Copiar Contexto Otimizado para IA**: Empacota deterministicamente as assinaturas tipadas e contratos de rotas com comprovante de economia de tokens para colar diretamente no ChatGPT, Claude, Gemini ou Cursor.
   - 📄 **Exportar Relatório MD**: Baixa instantaneamente o relatório executivo `MRCP_DIAGNOSTIC_REPORT.md`.
   - ⚙️ **Configurações de Tokens (GitHub & GitLab)**: Permite configurar tokens de acesso pessoal para elevar limites de requisições e auditar repositórios privados.

---

## 📦 Como Instalar no Google Chrome

### Opção A: Instalação Rápida via Arquivo Empacotado (.zip)
1. Baixe ou localize o arquivo de instalação empacotado:
   - `mrcp-chrome-extension-v2.6.1.zip`
2. Extraia o arquivo `.zip` em uma pasta de sua preferência no computador.
3. Abra o Google Chrome e acerte o endereço: `chrome://extensions`.
4. No canto superior direito, ative a opção **"Modo do desenvolvedor"** (Developer mode).
5. Clique no botão **"Carregar sem compactação"** (Load unpacked).
6. Selecione a pasta extraída onde se encontra o arquivo `manifest.json`.
7. A extensão **MRCP Engine** estará instalada e pronta para uso!

### Opção B: Instalação Direta a partir desta Pasta
1. Abra o navegador Google Chrome.
2. Acesse `chrome://extensions` na barra de endereços.
3. Ative a chave **"Modo do desenvolvedor"** (Developer mode) no canto superior direito.
4. Clique no botão **"Carregar sem compactação"** (Load unpacked).
5. Selecione a pasta deste projeto:
   ```
   D:\faels\Downloads\dev_4 - OK-20260913T222854Z-1-001\mrcp-chrome-extension
   ```
6. A extensão **MRCP Engine** aparecerá imediatamente na sua barra de ferramentas!
7. *(Recomendado)* Clique no ícone de quebra-cabeça na barra do Chrome e fixe o ícone do **MRCP Engine** para abrir o painel lateral em 1 clique.

---

## 🖥️ Como Usar

### 1. Analisando repositórios abertos no navegador
- Navegue até qualquer repositório no GitHub ou GitLab (ex: `https://github.com/expressjs/express`, `https://gitlab.com/gitlab-org/gitlab-runner` ou seus próprios projetos).
- O botão **⚡ MRCP Cockpit** estará disponível no cabeçalho da página ou clique no ícone da extensão para abrir o painel lateral.
- O painel lateral detectará dinamicamente o repositório da aba ativa.
- Clique em **"⚡ Analisar Aba"** para iniciar a auditoria em 1 clique.

### 2. Analisando repositórios manuais
- Digite qualquer slug (ex: `facebook/react`, `pallets/flask`, `gitlab:gitlab-org/gitlab-runner`) ou cole a URL no campo de busca.
- Clique em **⚡ Analisar**.

### 3. Copiando o Contexto Otimizado para IA
- Após a conclusão da análise, clique no botão **"📋 Copiar Contexto Otimizado para IA"** no rodapé do painel.
- O contexto pronto (com interfaces, funções, tipos e contratos de rota) é copiado para a Área de Transferência.
- Cole no seu assistente de IA favorito (ChatGPT, Claude, Gemini, Cursor) para obter respostas sem alucinações e com economia real de tokens.

---

## 🧪 Executando os Testes Automatizados

O motor analítico possui uma suíte completa de testes unitários para o Node.js:

```bash
cd "D:\faels\Downloads\dev_4 - OK-20260913T222854Z-1-001\mrcp-chrome-extension"
node test/engine.test.js
```

Testes inclusos:
- Parsing e validação de URLs remotas (GitHub e GitLab, branches, shorthands, sanitização)
- Extração de interfaces, tipos, classes e enums TypeScript/JavaScript
- Cálculo de complexidade ciclomática e Maintainability Index (SEI)
- Auditoria de regras de segurança e segredos (AWS, GitHub tokens, senhas)
- Detecção de ciclos de dependência (DFS)
- Detecção de God Modules (>750 linhas ou densidade crítica)
- Extração de rotas Express, Next.js e unificadas
- Empacotador de Contexto para IA com comprovante de economia de tokens
- Exportador de relatório Markdown diagnóstico
