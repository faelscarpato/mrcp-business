// engine/metrics.js - MRCP Engine Metrics & Dependency Cycles

import { pathUtils } from "./path-utils.js";

export function detectDuplicateModules(fileContentsMap) {
  const duplicates = [];
  const files = Array.from(fileContentsMap.keys());

  const srcAnalysisFiles = files.filter((f) =>
    f.replace(/\\/g, "/").startsWith("src/lib/analysis/")
  );
  const coreAnalysisFiles = files.filter((f) =>
    f.replace(/\\/g, "/").startsWith("packages/core/lib/analysis/")
  );

  if (srcAnalysisFiles.length > 0 && coreAnalysisFiles.length > 0) {
    for (const srcFile of srcAnalysisFiles) {
      const baseName = pathUtils.basename(srcFile);
      const coreFile = `packages/core/lib/analysis/${baseName}`;
      if (fileContentsMap.has(coreFile)) {
        const srcContent = fileContentsMap.get(srcFile) || "";
        const coreContent = fileContentsMap.get(coreFile) || "";

        if (srcContent.trim().startsWith("export * from")) {
          continue; // Re-export intencional não é duplicado
        }

        const equivalent = srcContent === coreContent;
        if (equivalent) {
          duplicates.push({
            primary: coreFile,
            duplicate: srcFile,
            contentEquivalent: true,
            risk: "low",
          });
        }
      }
    }
  }

  return duplicates;
}

export function resolveImportPaths(file, rawImports, allFiles) {
  const resolved = [];
  const currentDir = pathUtils.dirname(file);

  for (const imp of rawImports) {
    if (imp.startsWith(".")) {
      const joined = pathUtils.join(currentDir, imp);
      const normalized = pathUtils.normalize(joined);

      for (const f of allFiles) {
        const fNorm = pathUtils.normalize(f);
        const fNoExt = fNorm.replace(/\.[^/.]+$/, "");
        if (
          fNorm === normalized ||
          fNoExt === normalized ||
          fNorm === `${normalized}/index.ts` ||
          fNorm === `${normalized}/index.js`
        ) {
          resolved.push(fNorm);
          break;
        }
      }
    }
  }

  return resolved;
}

export function findCycles(graph) {
  const cycles = [];
  const visited = new Set();
  const recStack = new Set();
  const pathStack = [];

  function dfs(node) {
    visited.add(node);
    recStack.add(node);
    pathStack.push(node);

    const neighbors = graph.get(node) || [];
    for (const neighbor of neighbors) {
      if (!visited.has(neighbor)) {
        dfs(neighbor);
      } else if (recStack.has(neighbor)) {
        const cycleStartIndex = pathStack.indexOf(neighbor);
        if (cycleStartIndex !== -1) {
          const cyclePath = pathStack.slice(cycleStartIndex);
          cyclePath.push(neighbor);
          if (cyclePath.length > 2) {
            cycles.push({
              files: cyclePath,
              length: cyclePath.length - 1,
            });
          }
        }
      }
    }

    pathStack.pop();
    recStack.delete(node);
  }

  for (const node of graph.keys()) {
    if (!visited.has(node)) {
      dfs(node);
    }
  }

  return cycles.slice(0, 10);
}
