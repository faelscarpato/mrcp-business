// engine/analyzer-helpers.js - Helper analyzers for docs, dead code, and test gaps

import { pathUtils } from "./path-utils.js";

export const IGNORED_DIRS = new Set([
  "node_modules",
  ".git",
  "dist",
  "out",
  "build",
  ".next",
  ".turbo",
  "coverage",
  ".gemini",
  ".cache",
  ".vercel",
  "vendor",
  "obj",
  ".output",
  "temp",
  "tmp",
]);

export function processDocumentFiles(docFiles, fileContentsMap) {
  const docItems = [];
  for (const docPath of docFiles) {
    const norm = docPath.replace(/\\/g, "/");
    const content = fileContentsMap.get(docPath) || "";
    const ext = pathUtils.extname(docPath).toLowerCase().replace(".", "");

    let wordCount = 0;
    let quality = 85;

    if (["md", "txt", "csv", "json", "yaml", "yml", "log"].includes(ext)) {
      wordCount = content.split(/\s+/).filter(Boolean).length;
      if (wordCount < 10) quality = 40;
      else if (wordCount > 500) quality = 95;
    } else {
      wordCount = Math.floor(content.length / 6);
      quality = 90;
    }

    docItems.push({
      file: norm,
      format: ext.toUpperCase(),
      size: content.length,
      wordCount,
      qualityScore: quality,
    });
  }
  return docItems;
}

export function detectDeadCode(
  allExportedSymbols,
  allImportedSymbolNames,
  fileContentsMap
) {
  const deadCodeItems = [];

  for (const [, item] of allExportedSymbols.entries()) {
    const relPath = item.file;
    const symName = item.name;

    const isPublicModule =
      relPath.startsWith("packages/core/lib/") ||
      relPath.startsWith("api/") ||
      relPath.startsWith("bin/") ||
      relPath.includes("index.") ||
      relPath.includes("extension.") ||
      relPath.includes("types.") ||
      relPath.includes("main.") ||
      relPath.startsWith("src/index");

    if (isPublicModule) continue;
    if (allImportedSymbolNames.has(symName)) continue;

    let hasReference = false;
    const wordRegex = new RegExp(`\\b${escapeRegExp(symName)}\\b`, "g");
    const selfContent = fileContentsMap.get(relPath) || "";
    const selfOccurrences = (selfContent.match(wordRegex) || []).length;
    if (selfOccurrences > 1) hasReference = true;

    if (!hasReference) {
      for (const [otherPath, otherContent] of fileContentsMap.entries()) {
        if (otherPath === relPath) continue;
        if (wordRegex.test(otherContent)) {
          hasReference = true;
          break;
        }
      }
    }

    if (!hasReference) {
      deadCodeItems.push({
        file: relPath,
        symbolName: symName,
        kind: item.kind,
        line: item.line,
        reason: "Export declarado mas sem referências externas no repositório.",
      });
    }
  }

  return deadCodeItems.slice(0, 30);
}

export function detectTestGaps(analyzedFiles) {
  const gaps = [];

  for (const file of analyzedFiles) {
    const isTestFile =
      file.relativePath.toLowerCase().includes(".test.") ||
      file.relativePath.toLowerCase().includes(".spec.") ||
      file.relativePath.toLowerCase().includes("/test") ||
      file.relativePath.toLowerCase().includes("/__tests__/");

    if (isTestFile) continue;

    for (const sym of file.symbols) {
      if (
        (sym.kind === "function" || sym.kind === "method") &&
        sym.isExported &&
        sym.complexity >= 4 &&
        !sym.hasTests
      ) {
        gaps.push({
          file: file.relativePath,
          functionName: sym.name,
          line: sym.line,
          type: sym.kind,
          complexity: sym.complexity,
        });
      }
    }
  }

  return gaps.slice(0, 30);
}

function escapeRegExp(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
