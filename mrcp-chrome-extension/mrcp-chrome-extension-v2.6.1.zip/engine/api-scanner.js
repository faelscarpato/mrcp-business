// engine/api-scanner.js - MRCP Engine API Scanner & Contract Extractor

import { pathUtils } from "./path-utils.js";

export function extractApiRoutes(codeFiles, fileContentsMap) {
  const apiRoutes = [];

  // 1. Unified routes file: api/routes.ts
  if (fileContentsMap.has("api/routes.ts")) {
    const content = fileContentsMap.get("api/routes.ts") || "";
    const lines = content.split("\n");

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const lineNum = i + 1;
      const match = line.match(/['"](\/api\/[a-zA-Z0-9_\-/]+)['"]\s*:/);
      if (match) {
        const canonical = match[1];
        const isAlias = line.includes("routeHandlers[");
        if (isAlias) continue;

        const aliases = [];
        for (let j = i + 1; j < Math.min(lines.length, i + 8); j++) {
          const aMatch = lines[j].match(
            /['"](\/api\/[a-zA-Z0-9_\-/]+)['"]\s*:\s*.*routeHandlers\[['"]([^'"]+)['"]\]/
          );
          if (aMatch && aMatch[2] === canonical) {
            aliases.push(aMatch[1]);
          }
        }

        if (!apiRoutes.some((r) => r.path === canonical)) {
          apiRoutes.push({
            method: "GET",
            acceptedMethods: ["GET", "POST", "OPTIONS"],
            path: canonical,
            file: "api/routes.ts",
            line: lineNum,
            handler: "handler",
            aliases,
            source: "static-condition",
            description: "Aceita GET, POST via dispatcher unificado",
          });
        }
      }
    }
  }

  // 2. Scan api/mcp.ts explicitly
  if (fileContentsMap.has("api/mcp.ts")) {
    if (!apiRoutes.some((r) => r.path === "/api/mcp")) {
      apiRoutes.push({
        method: "POST",
        acceptedMethods: ["POST", "GET", "OPTIONS"],
        path: "/api/mcp",
        file: "api/mcp.ts",
        line: 1,
        handler: "handler",
        aliases: [],
        source: "mcp-protocol",
        description:
          "POST (JSON-RPC 2.0 execution) | GET (Discovery & Healthcheck)",
      });
    }
  }

  // 3. Scan Next.js API Routes (pages/api/* or app/api/*)
  for (const f of codeFiles) {
    const norm = f.replace(/\\/g, "/");

    // Pages router: pages/api/foo.ts -> /api/foo
    if (norm.startsWith("pages/api/") || norm.includes("/pages/api/")) {
      const sub = norm.substring(norm.indexOf("pages/api/") + 10);
      const routePath = "/api/" + sub.replace(/\.(ts|js|tsx|jsx)$/, "").replace(/\/index$/, "");
      if (!apiRoutes.some((r) => r.path === routePath)) {
        apiRoutes.push({
          method: "GET",
          acceptedMethods: ["GET", "POST", "PUT", "DELETE"],
          path: routePath,
          file: norm,
          line: 1,
          handler: "handler",
          aliases: [],
          source: "file-based",
          description: "Next.js Pages API Route",
        });
      }
    }

    // App router: app/api/foo/route.ts -> /api/foo
    if (norm.endsWith("/route.ts") || norm.endsWith("/route.js")) {
      if (norm.includes("app/api/")) {
        const sub = norm.substring(norm.indexOf("app/api/") + 8);
        const routePath = "/api/" + sub.replace(/\/route\.(ts|js)$/, "");
        const content = fileContentsMap.get(f) || "";
        const methods = [];
        for (const m of ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]) {
          if (new RegExp(`export\\s+(?:async\\s+)?function\\s+${m}\\b`).test(content)) {
            methods.push(m);
          }
        }
        if (!apiRoutes.some((r) => r.path === routePath)) {
          apiRoutes.push({
            method: methods[0] || "GET",
            acceptedMethods: methods.length > 0 ? methods : ["GET"],
            path: routePath,
            file: norm,
            line: 1,
            handler: "routeHandler",
            aliases: [],
            source: "file-based",
            description: `Next.js App Route [${methods.join(", ") || "GET"}]`,
          });
        }
      }
    }

    // Generic api/*.ts
    if (
      norm.startsWith("api/") &&
      norm !== "api/routes.ts" &&
      norm !== "api/index.ts" &&
      norm !== "api/mcp.ts"
    ) {
      const routePath =
        "/" + norm.replace(/\.(ts|js)$/, "").replace(/\/index$/, "");
      if (!apiRoutes.some((r) => r.path === routePath)) {
        const isPost = norm.includes("refactor") || norm.includes("diff");
        apiRoutes.push({
          method: isPost ? "POST" : "GET",
          acceptedMethods: isPost
            ? ["POST", "OPTIONS"]
            : ["GET", "POST", "OPTIONS"],
          path: routePath,
          file: norm,
          line: 1,
          handler: "defaultHandler",
          aliases: [],
          source: "file-based",
          description: "File-based REST handler",
        });
      }
    }

    // Express / Fastify / Koa in code: app.get('/...', ...), router.post('/...', ...)
    const content = fileContentsMap.get(f) || "";
    if (
      content.includes("app.get") ||
      content.includes("app.post") ||
      content.includes("router.get") ||
      content.includes("router.post") ||
      content.includes("app.route") ||
      content.includes("@app.get") ||
      content.includes("@router.")
    ) {
      const expressRegex =
        /(?:app|router)\.(get|post|put|delete|patch)\s*\(\s*['"]([^'"]+)['"]/gi;
      let eMatch;
      while ((eMatch = expressRegex.exec(content)) !== null) {
        const method = eMatch[1].toUpperCase();
        const routePath = eMatch[2];
        const lineNum = content.substring(0, eMatch.index).split("\n").length;

        if (!apiRoutes.some((r) => r.path === routePath && r.file === norm)) {
          apiRoutes.push({
            method: method,
            acceptedMethods: [method],
            path: routePath,
            file: norm,
            line: lineNum,
            handler: "expressHandler",
            aliases: [],
            source: "express-route",
            description: `Express/Router ${method} handler`,
          });
        }
      }

      // Python FastAPI / Flask: @app.get("/...") or @router.post("/...")
      const pyRouteRegex =
        /@(?:app|router)\.(get|post|put|delete|patch|route)\s*\(\s*['"]([^'"]+)['"]/gi;
      let pyMatch;
      while ((pyMatch = pyRouteRegex.exec(content)) !== null) {
        const verb = pyMatch[1].toUpperCase();
        const method = verb === "ROUTE" ? "GET" : verb;
        const routePath = pyMatch[2];
        const lineNum = content.substring(0, pyMatch.index).split("\n").length;

        if (!apiRoutes.some((r) => r.path === routePath && r.file === norm)) {
          apiRoutes.push({
            method: method,
            acceptedMethods: [method],
            path: routePath,
            file: norm,
            line: lineNum,
            handler: "fastapiHandler",
            aliases: [],
            source: "express-route",
            description: `FastAPI / Flask ${method} endpoint`,
          });
        }
      }
    }
  }

  return apiRoutes;
}
