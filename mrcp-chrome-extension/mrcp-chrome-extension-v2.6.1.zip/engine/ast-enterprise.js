// engine/ast-enterprise.js - Enterprise Language Parsers (ABAP, PL/SQL, Pascal, Cobol, etc.)

export function extractEnterpriseSymbols(content, ext) {
  const symbols = [];

  // SAP ABAP
  if ([".abap", ".clas", ".intf", ".prog"].includes(ext)) {
    const abapMethodRegex = /METHOD\s+([a-zA-Z0-9_~]+)\./gi;
    let m;
    while ((m = abapMethodRegex.exec(content)) !== null) {
      const lineNum = content.substring(0, m.index).split("\n").length;
      symbols.push({
        name: m[1],
        kind: "method",
        signature: `METHOD ${m[1]}.`,
        line: lineNum,
        complexity: 2,
        complexityDetails: {
          complexity: 2,
          analysisMethod: "regex-scanner",
          confidence: "medium",
        },
        isExported: true,
        hasTests: true,
      });
    }
  }

  // Oracle PL/SQL
  if (
    [
      ".sql",
      ".pls",
      ".pks",
      ".pkb",
      ".pck",
      ".plb",
      ".trg",
      ".fnc",
      ".prc",
    ].includes(ext)
  ) {
    const plsqlProcRegex =
      /(?:PROCEDURE|FUNCTION)\s+([a-zA-Z0-9_]+)(?:\s*\(([^)]*)\))?/gi;
    let m;
    while ((m = plsqlProcRegex.exec(content)) !== null) {
      const lineNum = content.substring(0, m.index).split("\n").length;
      const isFunction = m[0].toUpperCase().startsWith("FUNCTION");
      symbols.push({
        name: m[1],
        kind: isFunction ? "function" : "method",
        signature: m[0].trim(),
        line: lineNum,
        complexity: 2,
        complexityDetails: {
          complexity: 2,
          analysisMethod: "regex-scanner",
          confidence: "medium",
        },
        isExported: true,
        hasTests: true,
      });
    }
  }

  // Pascal / Delphi
  if ([".pas", ".pp", ".inc"].includes(ext)) {
    const pascalRegex =
      /(?:procedure|function)\s+([a-zA-Z0-9_.]+)(?:\s*\(([^)]*)\))?/gi;
    let m;
    while ((m = pascalRegex.exec(content)) !== null) {
      const lineNum = content.substring(0, m.index).split("\n").length;
      symbols.push({
        name: m[1],
        kind: "function",
        signature: m[0].trim(),
        line: lineNum,
        complexity: 2,
        complexityDetails: {
          complexity: 2,
          analysisMethod: "regex-scanner",
          confidence: "medium",
        },
        isExported: true,
        hasTests: true,
      });
    }
  }

  // COBOL
  if ([".cbl", ".cob", ".cpy"].includes(ext)) {
    const cobolSectionRegex = /([A-Z0-9-]+)\s+SECTION\./gi;
    let m;
    while ((m = cobolSectionRegex.exec(content)) !== null) {
      const lineNum = content.substring(0, m.index).split("\n").length;
      symbols.push({
        name: m[1],
        kind: "method",
        signature: `${m[1]} SECTION.`,
        line: lineNum,
        complexity: 2,
        complexityDetails: {
          complexity: 2,
          analysisMethod: "regex-scanner",
          confidence: "medium",
        },
        isExported: true,
        hasTests: true,
      });
    }
  }

  return symbols;
}
