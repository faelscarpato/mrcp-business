// engine/ast-helpers.js - MRCP Engine AST Helpers

export const CODE_EXTENSIONS = new Set([
  ".ts",
  ".tsx",
  ".js",
  ".jsx",
  ".mjs",
  ".cjs",
  ".py",
  ".go",
  ".rs",
  ".java",
  ".c",
  ".cpp",
  ".php",
  ".rb",
  ".cs",
  ".cds",
  ".abap",
  ".clas",
  ".intf",
  ".prog",
  ".sql",
  ".pls",
  ".pks",
  ".pkb",
  ".pck",
  ".plb",
  ".trg",
  ".fnc",
  ".prc",
  ".pas",
  ".pp",
  ".inc",
  ".cbl",
  ".cob",
  ".cpy",
]);

export const DOC_EXTENSIONS = new Set([
  ".md",
  ".txt",
  ".csv",
  ".json",
  ".yaml",
  ".yml",
  ".docx",
  ".pdf",
  ".xlsx",
  ".log",
]);

export const SECRET_RULES = [
  {
    rule: "AWS Key",
    regex: /(?:AKIA|ASIA)[0-9A-Z]{16}/,
    severity: "critical",
    msg: "Chave de acesso da AWS codificada no código-fonte.",
  },
  {
    rule: "Generic Private Key",
    regex: /-----BEGIN (?:RSA|OPENSSH|EC|DSA) PRIVATE KEY-----/,
    severity: "critical",
    msg: "Chave criptográfica privada exposta no código.",
  },
  {
    rule: "GitHub Token",
    regex: /gh[pousr]_[0-9a-zA-Z]{36}/,
    severity: "critical",
    msg: "Token pessoal / OAuth do GitHub detectado.",
  },
  {
    rule: "Hardcoded JWT",
    regex: /eyJ[a-zA-Z0-9_-]{10,}\.eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}/,
    severity: "high",
    msg: "JSON Web Token (JWT) fixo detectado.",
  },
  {
    rule: "Dangerous Eval",
    regex: /(?<![/*a-zA-Z0-9_])eval\s*\([^)]+\)/,
    severity: "high",
    msg: "Risco de execução arbitrária de código com eval().",
  },
  {
    rule: "Hardcoded Password/Secret",
    regex:
      /(?:password|secret|apiKey|api_key|authToken)\s*[:=]\s*["'][a-zA-Z0-9_\-!@#$%^&*]{16,}["']/i,
    severity: "medium",
    msg: "Possível credencial ou segredo confidencial em texto claro.",
  },
];

export function getLanguageName(ext) {
  switch (ext) {
    case ".ts":
    case ".tsx":
      return "TypeScript";
    case ".js":
    case ".jsx":
    case ".mjs":
    case ".cjs":
      return "JavaScript";
    case ".py":
      return "Python";
    case ".go":
      return "Go";
    case ".rs":
      return "Rust";
    case ".java":
      return "Java";
    case ".c":
    case ".cpp":
      return "C/C++";
    case ".php":
      return "PHP";
    case ".rb":
      return "Ruby";
    case ".cs":
      return "C#";
    case ".cds":
      return "SAP CDS";
    case ".abap":
    case ".clas":
    case ".intf":
    case ".prog":
      return "SAP ABAP";
    case ".sql":
    case ".pls":
    case ".pks":
    case ".pkb":
    case ".pck":
    case ".plb":
    case ".trg":
    case ".fnc":
    case ".prc":
      return "Oracle PL/SQL";
    case ".pas":
    case ".pp":
    case ".inc":
      return "Pascal";
    case ".cbl":
    case ".cob":
    case ".cpy":
      return "COBOL";
    default:
      return "Outro";
  }
}

export function parseTypedParameters(raw) {
  if (!raw || !raw.trim()) return [];
  const result = [];
  const parts = splitParameters(raw);

  for (const part of parts) {
    const trimmed = part.trim();
    if (!trimmed) continue;

    const colonIdx = trimmed.indexOf(":");
    const eqIdx = trimmed.indexOf("=");

    let name = trimmed;
    let type = undefined;
    let optional = false;

    if (colonIdx !== -1) {
      name = trimmed.substring(0, colonIdx).trim();
      const afterColon = trimmed.substring(colonIdx + 1).trim();
      if (eqIdx !== -1 && eqIdx > colonIdx) {
        type = trimmed.substring(colonIdx + 1, eqIdx).trim();
        optional = true;
      } else {
        type = afterColon;
      }
    } else if (eqIdx !== -1) {
      name = trimmed.substring(0, eqIdx).trim();
      optional = true;
    }

    if (name.endsWith("?")) {
      name = name.slice(0, -1).trim();
      optional = true;
    }

    // Clean modifiers
    name = name.replace(/^(?:public|private|protected|readonly)\s+/, "");

    result.push({ name, type, optional });
  }

  return result;
}

function splitParameters(raw) {
  const parts = [];
  let depth = 0;
  let current = "";

  for (let i = 0; i < raw.length; i++) {
    const char = raw[i];
    if (char === "<" || char === "{" || char === "(" || char === "[") {
      depth++;
      current += char;
    } else if (char === ">" || char === "}" || char === ")" || char === "]") {
      depth--;
      current += char;
    } else if (char === "," && depth === 0) {
      parts.push(current);
      current = "";
    } else {
      current += char;
    }
  }

  if (current.trim()) {
    parts.push(current);
  }

  return parts;
}

export function calculateFunctionBodyComplexity(content, startIndex) {
  let complexity = 1;
  let depth = 1;
  let inBlock = false;

  for (let i = startIndex; i < content.length; i++) {
    const char = content[i];
    if (char === "{") {
      depth++;
      inBlock = true;
    } else if (char === "}") {
      depth--;
      if (inBlock && depth === 0) {
        const body = content.substring(startIndex, i);
        return complexity + countBranchingKeywords(body);
      }
    }
  }

  const snippet = content.substring(startIndex, startIndex + 600);
  return complexity + countBranchingKeywords(snippet);
}

function countBranchingKeywords(text) {
  let count = 0;
  const branchRegex =
    /\b(if|else if|for|while|case|catch|throw|return)\b|(?:\?\s*[^:]+\s*:)|(?:&&|\|\|)/g;
  const matches = text.match(branchRegex);
  if (matches) {
    count = Math.min(25, matches.length);
  }
  return count;
}
