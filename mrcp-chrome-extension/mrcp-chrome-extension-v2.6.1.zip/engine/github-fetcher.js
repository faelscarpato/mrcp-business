// engine/github-fetcher.js - Remote Repository Client (GitHub & GitLab)

import { CODE_EXTENSIONS, DOC_EXTENSIONS } from "./ast-helpers.js";
import { pathUtils } from "./path-utils.js";
import { IGNORED_DIRS } from "./analyzer-helpers.js";

export class GitHubFetcher {
  constructor(token = "", gitlabToken = "") {
    this.token = (token || "").trim();
    this.gitlabToken = (gitlabToken || "").trim();
    if (!this.gitlabToken && this.token.startsWith("glpat-")) {
      this.gitlabToken = this.token;
      this.token = "";
    }
  }

  setToken(token) {
    this.token = (token || "").trim();
    if (this.token.startsWith("glpat-")) {
      this.gitlabToken = this.token;
      this.token = "";
    }
  }

  setGitlabToken(token) {
    this.gitlabToken = (token || "").trim();
  }

  getHeaders(provider = "github") {
    if (provider === "gitlab") {
      const headers = {
        Accept: "application/json",
        "User-Agent": "MRCP-Engine-Chrome-Extension/2.6.1",
      };
      if (this.gitlabToken) {
        headers["PRIVATE-TOKEN"] = this.gitlabToken;
      }
      return headers;
    }

    const headers = {
      Accept: "application/vnd.github.v3+json",
      "User-Agent": "MRCP-Engine-Chrome-Extension/2.6.1",
    };
    if (this.token) {
      headers["Authorization"] = `Bearer ${this.token}`;
    }
    return headers;
  }

  parseRepoUrl(input) {
    if (!input || typeof input !== "string") return null;
    const clean = input.trim();

    // 1. GitLab URLs: https://gitlab.com/group/subgroup/project or with /-/tree/branch
    const glUrlRegex =
      /^https?:\/\/(?:www\.)?gitlab\.com\/([a-zA-Z0-9_\-./]+?)(?:\/-\/(?:tree|blob)\/([^/?#]+)|\/?$)/i;
    const glMatch = clean.match(glUrlRegex);
    if (glMatch) {
      let fullPath = glMatch[1].replace(/^\/+|\/+$/g, "");
      // Filter out non-repo paths
      const topLevel = fullPath.split("/")[0].toLowerCase();
      const glIgnored = [
        "explore",
        "dashboard",
        "users",
        "help",
        "search",
        "admin",
        "profile",
        "groups",
      ];
      if (!glIgnored.includes(topLevel) && fullPath.includes("/")) {
        const parts = fullPath.split("/");
        const repo = parts.pop().replace(/\.git$/, "");
        const owner = parts.join("/");
        return {
          provider: "gitlab",
          owner,
          repo,
          fullName: `${owner}/${repo}`,
          branch: glMatch[2] ? decodeURIComponent(glMatch[2]) : null,
        };
      }
    }

    // Explicit prefix gitlab:group/repo
    if (clean.toLowerCase().startsWith("gitlab:")) {
      const remainder = clean.substring(7).trim();
      const parts = remainder.split("/");
      if (parts.length >= 2) {
        const repoPart = parts.pop().replace(/\.git$/, "");
        const branchMatch = repoPart.match(/^(.*)@(.*)$/);
        let repo = repoPart;
        let branch = null;
        if (branchMatch) {
          repo = branchMatch[1];
          branch = branchMatch[2];
        }
        const owner = parts.join("/");
        return {
          provider: "gitlab",
          owner,
          repo,
          fullName: `${owner}/${repo}`,
          branch,
        };
      }
    }

    // 2. GitHub URLs: https://github.com/owner/repo or with /tree/branch
    const ghUrlRegex =
      /^https?:\/\/(?:www\.)?github\.com\/([a-zA-Z0-9_.-]+)\/([a-zA-Z0-9_.-]+)(?:\/(?:tree|blob)\/([^/?#]+))?/i;
    const ghMatch = clean.match(ghUrlRegex);
    if (ghMatch) {
      const owner = ghMatch[1];
      const repo = ghMatch[2].replace(/\.git$/, "");
      const ignored = [
        "settings",
        "marketplace",
        "explore",
        "topics",
        "trending",
        "collections",
        "notifications",
      ];
      if (!ignored.includes(owner.toLowerCase())) {
        return {
          provider: "github",
          owner,
          repo,
          fullName: `${owner}/${repo}`,
          branch: ghMatch[3] ? decodeURIComponent(ghMatch[3]) : null,
        };
      }
    }

    // Explicit prefix github:owner/repo
    if (clean.toLowerCase().startsWith("github:")) {
      const remainder = clean.substring(7).trim();
      const shortMatch = remainder.match(
        /^([a-zA-Z0-9_.-]+)\/([a-zA-Z0-9_.-]+)(?:@([a-zA-Z0-9_.-]+))?$/
      );
      if (shortMatch) {
        return {
          provider: "github",
          owner: shortMatch[1],
          repo: shortMatch[2].replace(/\.git$/, ""),
          fullName: `${shortMatch[1]}/${shortMatch[2].replace(/\.git$/, "")}`,
          branch: shortMatch[3] || null,
        };
      }
    }

    // 3. Shorthand: owner/repo or owner/repo@branch (default to GitHub)
    const shortRegex =
      /^([a-zA-Z0-9_.-]+)\/([a-zA-Z0-9_.-]+)(?:@([a-zA-Z0-9_.-]+))?$/;
    const shortMatch = clean.match(shortRegex);
    if (shortMatch) {
      return {
        provider: "github",
        owner: shortMatch[1],
        repo: shortMatch[2].replace(/\.git$/, ""),
        fullName: `${shortMatch[1]}/${shortMatch[2].replace(/\.git$/, "")}`,
        branch: shortMatch[3] || null,
      };
    }

    return null;
  }

  async getRepoInfo(owner, repo, provider = "github", fullName = "") {
    const projectSlug = fullName || `${owner}/${repo}`;

    if (provider === "gitlab") {
      const url = `https://gitlab.com/api/v4/projects/${encodeURIComponent(projectSlug)}`;
      try {
        const res = await fetch(url, { headers: this.getHeaders("gitlab") });
        if (res.ok) {
          const data = await res.json();
          return {
            default_branch: data.default_branch || "main",
            name: data.name || repo,
            description: data.description || "",
          };
        }
      } catch (err) {
        console.warn("[MRCP] Erro ao obter info do GitLab:", err);
      }
      return { default_branch: "main", name: repo };
    }

    const url = `https://api.github.com/repos/${owner}/${repo}`;
    const res = await fetch(url, { headers: this.getHeaders("github") });
    if (!res.ok) {
      if (res.status === 403 || res.status === 429) {
        throw new Error(
          "Limite de requisições do GitHub atingido (Rate Limit). Configure um Personal Access Token nas configurações para 5.000 reqs/hora."
        );
      }
      if (res.status === 404) {
        throw new Error(
          `Repositório '${owner}/${repo}' não encontrado ou é privado (configure um token com permissão de leitura).`
        );
      }
      throw new Error(`Erro na API do GitHub (${res.status}): ${res.statusText}`);
    }
    return await res.json();
  }

  async getTree(owner, repo, branch, provider = "github", fullName = "") {
    const projectSlug = fullName || `${owner}/${repo}`;

    if (provider === "gitlab") {
      let allItems = [];
      let page = 1;
      const maxPages = 5;

      while (page <= maxPages) {
        const url = `https://gitlab.com/api/v4/projects/${encodeURIComponent(
          projectSlug
        )}/repository/tree?recursive=true&ref=${encodeURIComponent(
          branch
        )}&per_page=100&page=${page}`;
        const res = await fetch(url, { headers: this.getHeaders("gitlab") });
        if (!res.ok) {
          if (page === 1) {
            throw new Error(
              `Falha ao obter árvore de arquivos do GitLab (${res.status}): ${res.statusText}`
            );
          }
          break;
        }
        const data = await res.json();
        if (!Array.isArray(data) || data.length === 0) break;
        allItems.push(...data);

        const nextPage = res.headers.get("x-next-page");
        if (!nextPage) break;
        page++;
      }

      return allItems.map((item) => ({
        path: item.path,
        type: item.type === "blob" ? "blob" : "tree",
        id: item.id,
      }));
    }

    const url = `https://api.github.com/repos/${owner}/${repo}/git/trees/${encodeURIComponent(
      branch
    )}?recursive=1`;
    const res = await fetch(url, { headers: this.getHeaders("github") });
    if (!res.ok) {
      if (res.status === 403 || res.status === 429) {
        throw new Error(
          "Rate limit da API do GitHub excedido. Adicione seu GitHub Token nas opções do MRCP para limite de 5.000 reqs/hora."
        );
      }
      throw new Error(
        `Falha ao obter árvore de arquivos (${res.status}): ${res.statusText}`
      );
    }
    const data = await res.json();
    return data.tree || [];
  }

  filterTreeFiles(treeItems) {
    const codeFiles = [];
    const docFiles = [];
    const envFiles = [];
    const allFilePaths = [];

    for (const item of treeItems) {
      if (item.type !== "blob") continue;
      const filePath = item.path;
      const parts = filePath.split("/");

      // Check ignored directories
      const isIgnored = parts.some((p) => IGNORED_DIRS.has(p));
      if (isIgnored) continue;

      allFilePaths.push(filePath);

      const ext = pathUtils.extname(filePath).toLowerCase();
      const base = pathUtils.basename(filePath).toLowerCase();

      if (base.startsWith(".env")) {
        envFiles.push(item);
      } else if (CODE_EXTENSIONS.has(ext)) {
        codeFiles.push(item);
      } else if (DOC_EXTENSIONS.has(ext)) {
        docFiles.push(item);
      }
    }

    return { codeFiles, docFiles, envFiles, allFilePaths };
  }

  async fetchFileContent(
    owner,
    repo,
    branch,
    filePath,
    provider = "github",
    fullName = ""
  ) {
    const projectSlug = fullName || `${owner}/${repo}`;

    if (provider === "gitlab") {
      // 1. Fast raw fetch from GitLab
      const rawUrl = `https://gitlab.com/${projectSlug}/-/raw/${encodeURIComponent(
        branch
      )}/${filePath}`;
      const headers = {};
      if (this.gitlabToken) {
        headers["PRIVATE-TOKEN"] = this.gitlabToken;
      }
      try {
        const res = await fetch(rawUrl, { headers });
        if (res.ok) {
          return await res.text();
        }
      } catch {
        // Fallback below
      }

      // 2. Fallback: GitLab API raw file
      const apiUrl = `https://gitlab.com/api/v4/projects/${encodeURIComponent(
        projectSlug
      )}/repository/files/${encodeURIComponent(filePath)}/raw?ref=${encodeURIComponent(
        branch
      )}`;
      try {
        const apiRes = await fetch(apiUrl, { headers: this.getHeaders("gitlab") });
        if (apiRes.ok) {
          return await apiRes.text();
        }
      } catch {
        // Failed
      }
      return "";
    }

    // GitHub Fetch
    // 1. Attempt fast raw fetch first (does not consume REST API quota)
    const rawUrl = `https://raw.githubusercontent.com/${owner}/${repo}/${encodeURIComponent(
      branch
    )}/${filePath}`;
    const headers = {};
    if (this.token) {
      headers["Authorization"] = `token ${this.token}`;
    }

    try {
      const res = await fetch(rawUrl, { headers });
      if (res.ok) {
        return await res.text();
      }
    } catch {
      // Fallback below
    }

    // 2. Fallback: GitHub API contents
    const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${filePath}?ref=${encodeURIComponent(
      branch
    )}`;
    try {
      const apiRes = await fetch(apiUrl, { headers: this.getHeaders("github") });
      if (apiRes.ok) {
        const data = await apiRes.json();
        if (data.content && data.encoding === "base64") {
          return decodeBase64Utf8(data.content);
        }
      }
    } catch {
      // Failed
    }

    return "";
  }

  async fetchBatchFiles(
    owner,
    repo,
    branch,
    fileItems,
    concurrency = 6,
    onProgress = null,
    provider = "github",
    fullName = ""
  ) {
    const contentsMap = new Map();
    let completed = 0;
    const total = fileItems.length;

    const queue = [...fileItems];
    const workers = Array.from({ length: concurrency }, async () => {
      while (queue.length > 0) {
        const item = queue.shift();
        if (!item) break;

        try {
          const text = await this.fetchFileContent(
            owner,
            repo,
            branch,
            item.path,
            provider,
            fullName
          );
          contentsMap.set(item.path, text);
        } catch (err) {
          console.warn(`[MRCP] Falha ao baixar ${item.path}:`, err);
          contentsMap.set(item.path, "");
        }

        completed++;
        if (onProgress) {
          onProgress(completed, total, item.path);
        }
      }
    });

    await Promise.all(workers);
    return contentsMap;
  }
}

function decodeBase64Utf8(b64) {
  try {
    const cleanB64 = b64.replace(/\s/g, "");
    const binString = atob(cleanB64);
    const bytes = Uint8Array.from(binString, (m) => m.charCodeAt(0));
    return new TextDecoder().decode(bytes);
  } catch {
    return "";
  }
}
