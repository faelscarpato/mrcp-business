// engine/mrcp-engine.js - Central Analysis Orchestrator for Chrome Extension

import { pathUtils } from "./path-utils.js";
import { CODE_EXTENSIONS, DOC_EXTENSIONS, SECRET_RULES } from "./ast-helpers.js";
import { GitHubFetcher } from "./github-fetcher.js";
import { processSingleCodeFile } from "./file-processor.js";
import { extractApiRoutes } from "./api-scanner.js";
import {
  processDocumentFiles,
  detectDeadCode,
  detectTestGaps,
  IGNORED_DIRS,
} from "./analyzer-helpers.js";
import {
  findCycles,
  detectDuplicateModules,
  resolveImportPaths,
} from "./metrics.js";

export class MrcpEngine {
  constructor(options = {}) {
    this.token = options.token || "";
    this.gitlabToken = options.gitlabToken || "";
    this.fetcher = new GitHubFetcher(this.token, this.gitlabToken);
  }

  setToken(token) {
    this.token = token;
    this.fetcher.setToken(token);
  }

  setGitlabToken(token) {
    this.gitlabToken = token;
    this.fetcher.setGitlabToken(token);
  }

  async analyzeRepository(repoInput, onProgress = null) {
    const startTime = Date.now();
    const parsed = this.fetcher.parseRepoUrl(repoInput);
    if (!parsed) {
      throw new Error(
        `Formato inválido para repositório: '${repoInput}'. Use 'owner/repo', URL do GitHub ('https://github.com/owner/repo') ou GitLab ('https://gitlab.com/group/repo').`
      );
    }

    const { owner, repo, provider, fullName, branch: parsedBranch } = parsed;
    onProgress?.(
      5,
      `Conectando ao repositório [${provider.toUpperCase()}] ${fullName}...`
    );

    const repoInfo = await this.fetcher.getRepoInfo(
      owner,
      repo,
      provider,
      fullName
    );
    const branch = parsedBranch || repoInfo.default_branch || "main";

    onProgress?.(
      15,
      `Escaneando árvore de arquivos [${provider}] na branch [${branch}]...`
    );
    const treeItems = await this.fetcher.getTree(
      owner,
      repo,
      branch,
      provider,
      fullName
    );

    const { codeFiles, docFiles, envFiles, allFilePaths } =
      this.fetcher.filterTreeFiles(treeItems);

    if (codeFiles.length === 0 && docFiles.length === 0) {
      throw new Error(
        `Nenhum arquivo de código ou documentação suportado encontrado no repositório ${fullName}.`
      );
    }

    // Sort code files by size/priority to prioritize core architecture
    codeFiles.sort((a, b) => {
      // Put entry points, index, router, api, main first
      const score = (p) => {
        let s = 0;
        if (p.includes("index.") || p.includes("main.")) s += 100;
        if (p.includes("routes.") || p.includes("router.")) s += 80;
        if (p.includes("api/") || p.includes("src/")) s += 50;
        return s;
      };
      return score(b.path) - score(a.path);
    });

    // Intelligent download budget to guarantee lightning performance (up to 120 files)
    const MAX_DOWNLOAD = 120;
    const selectedCodeFiles = codeFiles.slice(0, MAX_DOWNLOAD);
    const selectedDocFiles = docFiles.slice(0, 15);
    const filesToDownload = [
      ...envFiles,
      ...selectedDocFiles,
      ...selectedCodeFiles,
    ];

    onProgress?.(
      25,
      `Baixando ${filesToDownload.length} arquivos essenciais para análise AST...`
    );

    const fileContentsMap = await this.fetcher.fetchBatchFiles(
      owner,
      repo,
      branch,
      filesToDownload,
      6,
      (done, total, path) => {
        const pct = Math.round(25 + (done / total) * 35);
        const fileName = pathUtils.basename(path);
        onProgress?.(pct, `Baixando [${done}/${total}]: ${fileName}`);
      },
      provider,
      fullName
    );

    // Run in-memory analysis over downloaded contents
    return this.analyzeCore({
      workspaceRoot: fullName,
      branch,
      provider,
      allFilePaths,
      codeFiles: selectedCodeFiles.map((c) => c.path),
      docFiles: selectedDocFiles.map((d) => d.path),
      fileContentsMap,
      startTime,
      onProgress,
    });
  }

  async analyzeInMemoryFiles(workspaceName, fileContentsMap, onProgress = null) {
    const startTime = Date.now();
    const allFilePaths = Array.from(fileContentsMap.keys());
    const codeFiles = allFilePaths.filter((f) =>
      CODE_EXTENSIONS.has(pathUtils.extname(f).toLowerCase())
    );
    const docFiles = allFilePaths.filter((f) =>
      DOC_EXTENSIONS.has(pathUtils.extname(f).toLowerCase())
    );

    return this.analyzeCore({
      workspaceRoot: workspaceName,
      branch: "local",
      allFilePaths,
      codeFiles,
      docFiles,
      fileContentsMap,
      startTime,
      onProgress,
    });
  }

  async analyzeCore({
    workspaceRoot,
    branch,
    provider = "github",
    allFilePaths,
    codeFiles,
    docFiles,
    fileContentsMap,
    startTime,
    onProgress,
  }) {
    onProgress?.(65, "Processando variáveis de ambiente e testes...");

    // 1. Defined .env variables
    const definedEnvVars = new Set();
    for (const [f, content] of fileContentsMap.entries()) {
      const base = pathUtils.basename(f).toLowerCase();
      if (base.startsWith(".env")) {
        for (const line of content.split("\n")) {
          const match = line.match(/^\s*([A-Z0-9_]+)\s*=/i);
          if (match && match[1]) {
            definedEnvVars.add(match[1]);
          }
        }
      }
    }

    // 2. Cross-referencing test files
    const testFileMap = new Set();
    const allTestFilesContent = [];
    for (const f of allFilePaths) {
      const base = pathUtils.basename(f).toLowerCase();
      if (
        base.includes(".test.") ||
        base.includes(".spec.") ||
        base.startsWith("test_") ||
        f.includes("/tests/") ||
        f.includes("/__tests__/")
      ) {
        testFileMap.add(base);
        testFileMap.add(base.replace(/(\.test|\.spec)/, ""));
        if (fileContentsMap.has(f)) {
          allTestFilesContent.push(fileContentsMap.get(f) || "");
        }
      }
    }
    const combinedTestContent = allTestFilesContent.join("\n");

    const analyzedFiles = [];
    const godModules = [];
    const securityIssues = [];
    const envIssues = [];
    const importGraph = new Map();
    const allExportedSymbols = new Map();
    const allImportedSymbolNames = new Set();

    let totalRawBytes = 0;
    let totalFunctionComplexity = 0;
    let totalFunctionCount = 0;
    let totalFileMI = 0;

    // 3. Process Code Files
    for (let i = 0; i < codeFiles.length; i++) {
      const relPath = codeFiles[i].replace(/\\/g, "/");
      const content = fileContentsMap.get(relPath) || "";
      totalRawBytes += content.length;

      const percent = Math.round(65 + (i / Math.max(1, codeFiles.length)) * 20);
      onProgress?.(
        percent,
        `Analisando AST de ${pathUtils.basename(relPath)} (${i + 1}/${codeFiles.length})...`
      );

      const processed = processSingleCodeFile({
        filePath: relPath,
        relPath,
        content,
        statSize: content.length,
        allFilePaths,
        definedEnvVars,
        testFileMap,
        combinedTestContent,
        securityIssues,
        envIssues,
        godModules,
        allExportedSymbols,
        allImportedSymbolNames,
        importGraph,
      });

      totalFileMI += processed.fileNormalizedMI;
      totalFunctionComplexity += processed.fnComplexity;
      totalFunctionCount += processed.fnCount;
      analyzedFiles.push(processed.analysis);
    }

    // 4. Extract API Routes
    onProgress?.(85, "Extraindo contratos HTTP e métodos de despacho...");
    const apiRoutes = extractApiRoutes(codeFiles, fileContentsMap);

    // 5. Process Documents & DQI
    onProgress?.(88, "Calculando DQI e inteligência de documentação...");
    const docItems = processDocumentFiles(docFiles, fileContentsMap);

    // 6. Detect Dependency Cycles & Duplicates
    onProgress?.(92, "Detectando ciclos de importação e duplicação...");
    const dependencyCycles = findCycles(importGraph);
    const duplicateModules = detectDuplicateModules(fileContentsMap);

    // 7. Detect Dead Code & Test Gaps
    const deadCodeItems = detectDeadCode(
      allExportedSymbols,
      allImportedSymbolNames,
      fileContentsMap
    );
    const testGaps = detectTestGaps(analyzedFiles);

    // 8. Consolidate Metrics & Scores
    onProgress?.(97, "Consolidando métricas e cockpit executivo...");
    const totalFiles = analyzedFiles.length;
    const totalSymbols = analyzedFiles.reduce(
      (acc, f) => acc + f.symbols.length,
      0
    );
    const avgComplexity =
      totalFunctionCount > 0
        ? Math.round((totalFunctionComplexity / totalFunctionCount) * 10) / 10
        : 1.5;

    const maintainabilityIndex =
      totalFiles > 0 ? Math.round(totalFileMI / totalFiles) : 100;

    let healthScore = maintainabilityIndex;
    healthScore -= Math.min(
      20,
      securityIssues.filter(
        (s) => s.severity === "critical" || s.severity === "high"
      ).length * 8
    );
    healthScore -= Math.min(10, godModules.length * 2);
    healthScore -= Math.min(10, dependencyCycles.length * 4);
    healthScore = Math.max(10, Math.min(100, healthScore));

    let letterGrade = "A";
    if (healthScore >= 80) letterGrade = "A";
    else if (healthScore >= 68) letterGrade = "B";
    else if (healthScore >= 50) letterGrade = "C";
    else if (healthScore >= 35) letterGrade = "D";
    else letterGrade = "F";

    const docQualityAvg =
      docItems.length > 0
        ? Math.round(
            docItems.reduce((acc, d) => acc + d.qualityScore, 0) /
              docItems.length
          )
        : 100;

    const rawTokens = Math.round(totalRawBytes / 3.8);
    const mrcpTokens = Math.round(totalSymbols * 18 + totalFiles * 25);
    const tokenSavingsPercent =
      rawTokens > 0
        ? Math.min(
            98,
            Math.max(
              75,
              Math.round(((rawTokens - mrcpTokens) / rawTokens) * 100)
            )
          )
        : 95;

    const durationMs = Date.now() - startTime;
    const fingerprint = simpleHash(workspaceRoot + Date.now().toString());

    const provenance = {
      generatedAt: new Date().toISOString(),
      analyzerVersion: "2.6.1-chrome",
      repositoryRevision: branch,
      source: `${provider}-sidepanel`,
      workspaceFingerprint: fingerprint,
      includedExtensions: Array.from(CODE_EXTENSIONS),
      excludedDirectories: Array.from(IGNORED_DIRS),
      calculationVersion: "2.6.1-sei",
      cache: {
        used: false,
        valid: true,
        reason: null,
      },
    };

    onProgress?.(100, "Diagnóstico concluído com sucesso!");

    return {
      workspaceRoot,
      timestamp: new Date().toISOString(),
      totalDurationMs: durationMs,
      provenance,
      summary: {
        healthScore,
        letterGrade,
        maintainabilityIndex,
        totalFiles,
        totalLinesOfCode: analyzedFiles.reduce((acc, f) => acc + f.linesCount, 0),
        totalSymbols,
        avgComplexity,
        godModulesCount: godModules.length,
        securityIssuesCount: securityIssues.length,
        missingEnvCount: envIssues.length,
        dependencyCyclesCount: dependencyCycles.length,
        testGapsCount: testGaps.length,
        deadCodeCount: deadCodeItems.length,
        apiRoutesCount: apiRoutes.length,
        documentsCount: docItems.length,
        documentQualityScore: docQualityAvg,
        estimatedTokensWithoutMrcp: rawTokens,
        estimatedTokensWithMrcp: mrcpTokens,
        tokenSavingsPercent,
      },
      godModules,
      duplicateModules,
      files: analyzedFiles,
      securityIssues,
      envIssues,
      dependencyCycles,
      testGaps,
      deadCodeItems,
      apiRoutes,
      documents: docItems,
    };
  }
}

function simpleHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return Math.abs(hash).toString(16).padStart(12, "0").substring(0, 12);
}
