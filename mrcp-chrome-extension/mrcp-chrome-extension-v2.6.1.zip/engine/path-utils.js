// engine/path-utils.js - Browser-compatible path manipulation

export const pathUtils = {
  basename(filePath, ext) {
    if (!filePath) return "";
    const clean = filePath.replace(/\\/g, "/");
    const lastSlash = clean.lastIndexOf("/");
    let base = lastSlash === -1 ? clean : clean.slice(lastSlash + 1);
    if (ext && base.endsWith(ext)) {
      base = base.slice(0, -ext.length);
    }
    return base;
  },

  extname(filePath) {
    if (!filePath) return "";
    const base = pathUtils.basename(filePath);
    const lastDot = base.lastIndexOf(".");
    if (lastDot <= 0) return "";
    return base.slice(lastDot);
  },

  dirname(filePath) {
    if (!filePath) return ".";
    const clean = filePath.replace(/\\/g, "/");
    const lastSlash = clean.lastIndexOf("/");
    if (lastSlash === -1) return ".";
    if (lastSlash === 0) return "/";
    return clean.slice(0, lastSlash);
  },

  join(...parts) {
    return parts
      .filter(Boolean)
      .map((p) => p.replace(/\\/g, "/"))
      .join("/")
      .replace(/\/+/g, "/");
  },

  relative(from, to) {
    const fromParts = from.replace(/\\/g, "/").split("/").filter(Boolean);
    const toParts = to.replace(/\\/g, "/").split("/").filter(Boolean);
    let commonLen = 0;
    while (
      commonLen < fromParts.length &&
      commonLen < toParts.length &&
      fromParts[commonLen] === toParts[commonLen]
    ) {
      commonLen++;
    }
    const upCount = fromParts.length - commonLen;
    const result = [];
    for (let i = 0; i < upCount; i++) result.push("..");
    for (let i = commonLen; i < toParts.length; i++) result.push(toParts[i]);
    return result.join("/") || ".";
  },

  normalize(filePath) {
    return filePath.replace(/\\/g, "/").replace(/\/+/g, "/");
  },
};
